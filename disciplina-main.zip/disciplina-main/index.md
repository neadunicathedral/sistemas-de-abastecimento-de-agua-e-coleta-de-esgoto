<script language="JavaScript"> 
window.location="http://ead.unicathedral.edu.br"; 
</script> 
